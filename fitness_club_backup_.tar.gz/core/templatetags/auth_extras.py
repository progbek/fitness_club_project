# core/templatetags/auth_extras.py
from django import template

register = template.Library()

@register.filter(name='is_cashier')
def is_cashier(user):
    """Проверяет, является ли пользователь кассиром"""
    if not user.is_authenticated:
        return False
    # Получаем все названия групп пользователя в нижнем регистре
    group_names = [group.name.lower() for group in user.groups.all()]
    return 'кассиры' in group_names or 'cashiers' in group_names

@register.filter(name='is_manager')
def is_manager(user):
    """Проверяет, является ли пользователь руководителем"""
    if not user.is_authenticated:
        return False
    # Получаем все названия групп пользователя в нижнем регистре
    group_names = [group.name.lower() for group in user.groups.all()]
    return 'руководитель' in group_names or 'managers' in group_names

@register.filter(name='is_administrator')
def is_administrator(user):
    """Проверяет, является ли пользователь администратором"""
    if not user.is_authenticated:
        return False
    # Получаем все названия групп пользователя в нижнем регистре
    group_names = [group.name.lower() for group in user.groups.all()]
    return 'администраторы' in group_names or 'administrators' in group_names