# Импортируем модели
from core.models import Client, Subscription
from django.utils import timezone

# 1. Найдем нового проблемного клиента
# Последний созданный клиент
new_client = Client.objects.order_by('-id').first()
print("=== КЛИЕНТ ===")
print(f"ID: {new_client.id}, Имя: {new_client.first_name} {new_client.last_name}")
print(f"Face ID: {new_client.face_id}")

# 2. Проверим все его абонементы
subscriptions = new_client.subscriptions.all()
print(f"\n=== АБОНЕМЕНТЫ (всего: {subscriptions.count()}) ===")

for sub in subscriptions:
    print(f"\n--- Абонемент ID: {sub.id} ---")
    print(f"is_active: {sub.is_active}")
    print(f"paid_visits: {sub.paid_visits}")
    print(f"used_visits: {sub.used_visits}")
    print(f"last_access_date: {sub.last_access_date}")
    print(f"valid_until: {sub.valid_until}")
    print(f"Действует на момент проверки: {'Да' if sub.valid_until > timezone.now().date() else 'НЕТ!'}")

    # 3. Сымитируем проверку системы
    has_active_sub = sub.is_active and sub.paid_visits > sub.used_visits
    print(f"Система найдет этот абонемент активным? {has_active_sub}")

# 4. Проверим, что вообще возвращает метод поиска активного абонемента
active_sub = None
for subscription in new_client.subscriptions.all():
    if subscription.is_active and subscription.paid_visits > subscription.used_visits:
        active_sub = subscription
        break

print(f"\n=== РЕЗУЛЬТАТ ПРОВЕРКИ СИСТЕМЫ ===")
if active_sub:
    print(f"✅ Найден активный абонемент: {active_sub.id}")
else:
    print("❌ Активный абонемент не найден! Именно поэтому access denied.")